def polindromo(palindromo):    
    if palindromo==palindromo[::-1]:
        print("La palabra es palindromo")
    else:
        print("La palabra no es palindromo")